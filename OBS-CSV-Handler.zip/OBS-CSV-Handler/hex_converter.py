import re

def validate_hex_color(hex_value):
    """
    Convert a hex color string (e.g., #RRGGBB or #RRGGBBAA) to a decimal RGBA integer.
    Returns the RGBA decimal integer value or None if the input is invalid.
    """
    try:
        # Remove the leading '#' if present
        hex_value = hex_value.lstrip('#')

        # If the hex code is 6 digits, assume full opacity (FF)
        if len(hex_value) == 6:
            hex_value += 'FF'

        # Ensure the hex code is 8 digits
        if len(hex_value) != 8:
            return None

        # Convert hex to RGBA components
        r = int(hex_value[0:2], 16)
        g = int(hex_value[2:4], 16)
        b = int(hex_value[4:6], 16)
        a = int(hex_value[6:8], 16)

        # Combine into a single decimal RGBA integer
        rgba_decimal = (a << 24) | (r << 16) | (g << 8) | b

        return rgba_decimal
    except ValueError:
        return None  # Return None if there was an error in conversion

"""
    # Check if it's a valid 6-digit or 8-digit hex color (RGB or RGBA)
    if re.match(r'^[0-9A-Fa-f]{6}$', hex_value):
        # If it's a 6-digit hex (RGB), add full opacity (FF) for alpha
        hex_value += 'FF'
    elif re.match(r'^[0-9A-Fa-f]{8}$', hex_value):
        pass  # Already valid RGBA (8 digits)
    else:
        return None  # Invalid hex color format

    # Now process the hex string into RGBA (Red, Green, Blue, Alpha)
    try:
        r = int(hex_value[0:2], 16)
        g = int(hex_value[2:4], 16)
        b = int(hex_value[4:6], 16)
        a = int(hex_value[6:8], 16)
        # Return the RGBA integer color value (as per OBS requirement)
        return (r << 24) | (g << 16) | (b << 8) | a
    except ValueError:
        return None  # Invalid hex characters or conversion error
"""